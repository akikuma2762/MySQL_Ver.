﻿using dek_erpvis_v2.cls;
using dek_erpvis_v2.webservice;
using dekERP_dll.dekErp;
using Support;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;
using System.Web.UI;
using Newtonsoft.Json;
using System.Web.UI.WebControls;


namespace dek_erpvis_v2.pages.dp_CNC
{
    public partial class Enter_ReportView : System.Web.UI.Page
    {
        //--------------------------------引用 OR 參數---------------------------------------
        ERP_cnc CNC = new ERP_cnc();
        public string color = "";
        public string path = "";
        string acc = "";
        public StringBuilder tr = new StringBuilder();
        public StringBuilder th = new StringBuilder();
        DataTable dt_monthtotal = new DataTable();
        List<string> columns = new List<string>();
        public string mach = "";
        List<string> machlist = new List<string>();
        myclass myclass = new myclass();
        //--------------------------------引用 OR 參數---------------------------------------
        //------------------------------------事件-------------------------------------------
        //載入事件
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie userInfo = Request.Cookies["userInfo"];
            if (userInfo != null)
            {
                acc = DataTableUtils.toString(userInfo["user_ACC"]);
                path = 德大機械.get_title_web_path("DES");
                color = HtmlUtil.change_color(acc);

                if (HtmlUtil.check_power(acc, System.IO.Path.GetFileName(Request.PhysicalPath).Split('.')[0]) || myclass.user_view_check(System.IO.Path.GetFileName(Request.PhysicalPath).Split('.')[0], acc))
                {
                    if (!IsPostBack)
                        MainProcess();
                }
                else
                    Response.Write("<script>alert('您無此權限!');location.href='../index.aspx';</script>");
            }
            else
                Response.Redirect(myclass.logout_url);
        }

        //暫停事件
        protected void Button_Save_Click(object sender, EventArgs e)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"select * from (  SELECT  *, (SELECT  MIN(a.now_time) FROM record_worktime a WHERE workman_status = '出站'  AND a.mach_name = record_worktime.mach_name AND a.work_staff = record_worktime.work_staff AND a.now_time >= record_worktime.now_time AND a.manu_id = record_worktime.manu_id) exit_time FROM record_worktime WHERE workman_status = '入站') a where a.exit_time IS null and product_number='{TextBox_Number.Text}' and mach_name='{TextBox_Machine.Text}'  and now_time <='{DateTime.Now:yyyyMMddHHmmss}' ";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

            if (HtmlUtil.Check_DataTable(dt))
            {
                DataTable dt_clone = dt.Clone();
                int j = 0;
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = "SELECT max(_id) _id FROM record_worktime";
                DataTable dt_max = DataTableUtils.GetDataTable(sqlcmd);
                int max = HtmlUtil.Check_DataTable(dt_max) ? DataTableUtils.toInt(dt_max.Rows[0]["_id"].ToString()) + 1 : 1;
                string now_time = DateTime.Now.ToString("yyyyMMddHHmmss");
                //紀錄暫停原因跟類型
                foreach (DataRow row in dt.Rows)
                {
                    DataRow rows = dt_clone.NewRow();
                    rows["_id"] = max + j;
                    rows["mach_name"] = row["mach_name"];

                    rows["manu_id"] = row["manu_id"];
                    rows["product_number"] = row["product_number"];
                    rows["product_name"] = row["product_name"];
                    rows["work_staff"] = row["work_staff"];
                    rows["workman_status"] = "暫停";
                    rows["report_qty"] = "0";
                    rows["qty_status"] = "良品";
                    rows["now_time"] = now_time;
                    rows["stop_type"] = DropDownList_StopType.SelectedItem.Text;
                    rows["stop_reason"] = TextBox_content.Text;
                    rows["type_mode"] = "進站報工";
                    dt_clone.Rows.Add(rows);
                    j++;
                }
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                if (dt_clone.Rows.Count == DataTableUtils.Insert_TableRows("record_worktime", dt_clone))
                {
                    //更新狀態
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}' and product_number='{TextBox_Number.Text}'";
                    dt = DataTableUtils.GetDataTable(sqlcmd);
                    if (HtmlUtil.Check_DataTable(dt))
                    {
                        List<bool> ok = new List<bool>();
                        foreach (DataRow row in dt.Rows)
                        {
                            DataRow rows = dt.NewRow();
                            rows["_id"] = row["_id"];
                            rows["order_status"] = "暫停";
                            rows["last_updatetime"] = now_time;
                            rows["error_type"] = DropDownList_StopType.SelectedItem.Text;
                            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                            ok.Add(DataTableUtils.Update_DataRow("workorder_information", $"mach_name='{TextBox_Machine.Text}' and product_number='{TextBox_Number.Text}' and manu_id='{row["manu_id"]}'", rows));
                        }
                        if (ok.IndexOf(false) == -1)
                            Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存成功');location.href='Enter_ReportView.aspx';</script>");
                        else
                            Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_ReportView.aspx';</script>");
                    }
                }
                else
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_ReportView.aspx';</script>");
            }
        }

        //取消暫停事件
        protected void Button_Cancel_Click(object sender, EventArgs e)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"SELECT  * FROM (SELECT  *, (SELECT  MIN(a.now_time) FROM record_worktime a WHERE workman_status = '取消暫停' AND a.mach_name = record_worktime.mach_name AND a.work_staff = record_worktime.work_staff AND a.now_time >= record_worktime.now_time AND a.manu_id = record_worktime.manu_id) cancel_time FROM record_worktime WHERE workman_status = '暫停') a WHERE a.cancel_time IS NULL  and product_number='{TextBox_Number.Text}' and mach_name='{TextBox_Machine.Text}'  and now_time <='{DateTime.Now:yyyyMMddHHmmss}'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

            if (HtmlUtil.Check_DataTable(dt))
            {
                DataTable dt_clone = dt.Clone();
                int j = 0;
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = "SELECT max(_id) _id FROM record_worktime";
                DataTable dt_max = DataTableUtils.GetDataTable(sqlcmd);
                int max = HtmlUtil.Check_DataTable(dt_max) ? DataTableUtils.toInt(dt_max.Rows[0]["_id"].ToString()) + 1 : 1;
                string now_time = DateTime.Now.ToString("yyyyMMddHHmmss");
                //紀錄暫停原因跟類型
                foreach (DataRow row in dt.Rows)
                {
                    DataRow rows = dt_clone.NewRow();
                    rows["_id"] = max + j;
                    rows["mach_name"] = row["mach_name"];

                    rows["manu_id"] = row["manu_id"];
                    rows["product_number"] = row["product_number"];
                    rows["product_name"] = row["product_name"];
                    rows["work_staff"] = row["work_staff"];
                    rows["workman_status"] = "取消暫停";
                    rows["report_qty"] = "0";
                    rows["qty_status"] = "良品";
                    rows["now_time"] = now_time;
                    rows["type_mode"] = "進站報工";
                    dt_clone.Rows.Add(rows);
                    j++;
                }
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                if (dt_clone.Rows.Count == DataTableUtils.Insert_TableRows("record_worktime", dt_clone))
                {
                    //更新狀態
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}' and product_number='{TextBox_Number.Text}'";
                    dt = DataTableUtils.GetDataTable(sqlcmd);
                    if (HtmlUtil.Check_DataTable(dt))
                    {
                        List<bool> ok = new List<bool>();
                        foreach (DataRow row in dt.Rows)
                        {
                            DataRow rows = dt.NewRow();
                            rows["_id"] = row["_id"];
                            rows["order_status"] = "入站";
                            rows["last_updatetime"] = now_time;
                            rows["error_type"] = "";
                            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                            ok.Add(DataTableUtils.Update_DataRow("workorder_information", $"mach_name='{TextBox_Machine.Text}' and product_number='{TextBox_Number.Text}' and manu_id='{row["manu_id"]}'", rows));
                        }
                        if (ok.IndexOf(false) == -1)
                            Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存成功');location.href='Enter_ReportView.aspx';</script>");
                        else
                            Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_ReportView.aspx';</script>");
                    }
                }
                else
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_ReportView.aspx';</script>");
            }
        }

        //跳頁(跳至異常回復)
        protected void Button_jump_Click(object sender, EventArgs e)
        {
            List<string> list = new List<string>(TextBox_Staffs.Text.Split('#'));
            string staff = "";
            for (int i = 0; i < list.Count - 1; i++)
            {
                i++;
                staff += staff == "" ? list[i] : $"/{list[i]}";
            }
            string url = $"machine={TextBox_Machine.Text},number={TextBox_Number.Text},order={TextBox_Order.Text},show_name={TextBox_Show.Text},group={TextBox_Group.Text},type=進站報工,staff={staff}";
            Response.Redirect($"Error_Detail.aspx?key={WebUtils.UrlStringEncode(url)}");
        }

        //工單出站
        protected void Button_Exit_Click(object sender, EventArgs e)
        {
            //主要的報工之DATATABLE
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}'  and manu_id='{TextBox_Order.Text}' and type_mode='進站報工' ";
            DataTable dt_main = DataTableUtils.GetDataTable(sqlcmd);

            //若有多的會往這邊扣除之DATATABLE
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}'  and manu_id <> '{TextBox_Order.Text}' and type_mode='進站報工' and order_status ='入站' order by delivery asc";
            DataTable dt_secondary = DataTableUtils.GetDataTable(sqlcmd);

            string now_time = DateTime.Now.ToString("yyyyMMddHHmmss");
            if (HtmlUtil.Check_DataTable(dt_main) && dt_secondary != null)
            {
                //先填入良品
                double qty = DataTableUtils.toDouble(TextBox_Good.Text) * DataTableUtils.toDouble(DataTableUtils.toString(dt_main.Rows[0]["division"])) / DataTableUtils.toDouble(DataTableUtils.toString(dt_main.Rows[0]["multiplication"]));
                bool ok = Order_Exit(dt_main, dt_secondary, qty, now_time);

                //在搜尋一次，不然數量不會更新
                //主要的報工之DATATABLE
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}'  and manu_id='{TextBox_Order.Text}' and type_mode='進站報工' ";
                dt_main = DataTableUtils.GetDataTable(sqlcmd);

                //若有多的會往這邊扣除之DATATABLE
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}'  and manu_id <> '{TextBox_Order.Text}' and type_mode='進站報工' and order_status ='入站' order by delivery asc";
                dt_secondary = DataTableUtils.GetDataTable(sqlcmd);


                //填入不良->出站
                double bad_qty = DataTableUtils.toDouble(TextBox_badqty.Text) * DataTableUtils.toDouble(DataTableUtils.toString(dt_main.Rows[0]["division"])) / DataTableUtils.toDouble(DataTableUtils.toString(dt_main.Rows[0]["multiplication"]));
                ok = Bad_Exit(dt_main, dt_secondary, bad_qty, now_time);

                //在搜尋一次，不然數量不會更新
                //主要的報工之DATATABLE
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}'  and manu_id='{TextBox_Order.Text}' and type_mode='進站報工' ";
                dt_main = DataTableUtils.GetDataTable(sqlcmd);

                if (HtmlUtil.Check_DataTable(dt_main))
                    PostToERP(dt_main.Rows[0]["manu_id"].ToString(), dt_main.Rows[0]["mach_name"].ToString());

                //若有多的會往這邊扣除之DATATABLE
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}'  and manu_id <> '{TextBox_Order.Text}' and type_mode='進站報工' and order_status ='出站' and last_updatetime = '{now_time}' order by delivery asc";
                dt_secondary = DataTableUtils.GetDataTable(sqlcmd);
                if (HtmlUtil.Check_DataTable(dt_secondary))
                    foreach (DataRow row in dt_secondary.Rows)
                        PostToERP(row["manu_id"].ToString(), row["mach_name"].ToString());

                if (ok)
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存成功');location.href='Enter_ReportView.aspx';</script>");
                else
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_ReportView.aspx';</script>");
            }
            else
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_ReportView.aspx';</script>");
        }

        //欄位移動事件儲存
        protected void Button_SaveColumns_Click(object sender, EventArgs e)
        {
            HtmlUtil.Save_Columns(TextBox_SaveColumn.Text, System.IO.Path.GetFileName(Request.PhysicalPath).Split('.')[0], acc);
        }

        //選取顯示欄位與廠區群組
        protected void Button_Check_Click(object sender, EventArgs e)
        {
            //儲存需顯示之欄位
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"select * from show_column where Account='{acc}' and use_page='Enter_ReportView'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            if (dt != null)
            {
                //先刪除裡面的資料
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                DataTableUtils.Delete_Record("show_column", $"Account='{acc}' and use_page='Enter_ReportView'");

                //取得最大ID
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = "SELECT max(ID) ID FROM show_column";
                DataTable dt_max = DataTableUtils.GetDataTable(sqlcmd);
                int max = HtmlUtil.Check_DataTable(dt_max) ? DataTableUtils.toInt(dt_max.Rows[0]["ID"].ToString()) + 1 : 1;

                DataTable dt_clone = dt.Clone();

                for (int i = 0; i < CheckBoxList_Columns.Items.Count; i++)
                {
                    DataRow row = dt_clone.NewRow();
                    row["id"] = max + i;
                    row["Column_Name"] = CheckBoxList_Columns.Items[i].Text;
                    row["Account"] = acc;
                    row["Allow"] = CheckBoxList_Columns.Items[i].Selected ? "True" : "False";
                    row["use_page"] = "Enter_ReportView";
                    dt_clone.Rows.Add(row);
                }
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                if (DataTableUtils.Insert_TableRows("show_column", dt_clone) == dt_clone.Rows.Count)
                {
                    DropDownList_MachType.SelectedIndex = DropDownList_MachType.Items.IndexOf(DropDownList_MachType.Items.FindByValue(TextBox_MachTypeValue.Text));
                    DropDownList_MachGroup.Items.Clear();
                    List<string> list = new List<string>(TextBox_MachTypeValue.Text.Split(','));
                    for (int i = 0; i < list.Count - 1; i++)
                    {
                        ListItem listItem = new ListItem(list[i], list[i + 1]);
                        DropDownList_MachGroup.Items.Add(listItem);
                        i++;
                    }
                    DropDownList_MachGroup.SelectedIndex = DropDownList_MachGroup.Items.IndexOf(DropDownList_MachGroup.Items.FindByText(TextBox_MachGroupText.Text));

                    machlist = new List<string>(TextBox_Machines.Text.Split(','));
                    MainProcess();
                }
                else
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_ReportView.aspx';</script>");
            }
            else
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_ReportView.aspx';</script>");
        }

        //須執行之副程式
        private void MainProcess()
        {
            if (WebUtils.GetAppSettings("add_maintain") == "1")
                Maintain_to_Report();
            Set_Dropdownlist();
            Set_Factory();
            Set_Checkbox();
            Get_MonthTotal();
            Set_Table();
        }

        //取得目前所有的狀態為未出站的資料
        private void Get_MonthTotal()
        {
            if (machlist.Count > 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                string sqlcmd = "select * from machine_info";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
                if (HtmlUtil.Check_DataTable(dt))
                {
                    for (int i = 0; i < machlist.Count; i++)
                    {
                        DataRow[] rows = dt.Select($"mach_show_name='{machlist[i]}'");
                        if (rows != null && rows.Length > 0)
                            machlist[i] = DataTableUtils.toString(rows[0]["mach_name"]);
                    }
                }
            }
            dt_monthtotal = CNC.Enter_ReportView("cnc", machlist);
        }

        //設定核取方塊
        private void Set_Checkbox()
        {
            CheckBoxList_Columns.Items.Clear();
            //找到系統預設的
            DataTable dt_System = CNC.System_columns("Enter_ReportView");
            //找到個人設定的
            DataTable dt_Person = CNC.Person_columns("Enter_ReportView", acc);

            //個人的
            if (HtmlUtil.Check_DataTable(dt_System))
            {
                ListItem listItem = new ListItem();
                //個人的
                if (HtmlUtil.Check_DataTable(dt_Person))
                {
                    foreach (DataRow row in dt_System.Rows)
                    {
                        listItem = new ListItem(DataTableUtils.toString(row["info_chinese"]), DataTableUtils.toString(row["info_name"]));
                        var select = dt_Person.AsEnumerable().Where(w => w.Field<string>("info_name") == DataTableUtils.toString(row["info_name"]));
                        if (select.FirstOrDefault() != null)
                        {
                            listItem.Selected = true;
                            columns.Add(DataTableUtils.toString(row["info_chinese"]));
                        }
                        CheckBoxList_Columns.Items.Add(listItem);
                    }
                }
                //系統的
                else
                {
                    foreach (DataRow row in dt_System.Rows)
                    {
                        listItem = new ListItem(DataTableUtils.toString(row["info_chinese"]), DataTableUtils.toString(row["info_name"]));
                        listItem.Selected = true;
                        columns.Add(DataTableUtils.toString(row["info_chinese"]));
                        CheckBoxList_Columns.Items.Add(listItem);
                    }
                }
                columns.Add("");
            }

        }

        //設定異常類型
        private void Set_Dropdownlist()
        {
            if (DropDownList_StopType.Items.Count == 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                string sqlcmd = "select * from error_type where err_type_title = '暫停類型' and err_type <> 'ERROR'";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
                if (HtmlUtil.Check_DataTable(dt))
                {
                    DropDownList_StopType.Items.Clear();
                    ListItem list = new ListItem();
                    foreach (DataRow row in dt.Rows)
                    {
                        list = new ListItem(DataTableUtils.toString(row["err_type"]));
                        DropDownList_StopType.Items.Add(list);
                    }
                    list = new ListItem("ERROR");
                    DropDownList_StopType.Items.Add(list);
                }
            }

            if (DropDownList_bad.Items.Count == 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                string sqlcmd = "select * from error_type where err_type_title = '不良類型'";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                if (HtmlUtil.Check_DataTable(dt))
                {
                    DropDownList_bad.Items.Clear();
                    ListItem list = new ListItem();
                    list = new ListItem("");
                    DropDownList_bad.Items.Add(list);
                    foreach (DataRow row in dt.Rows)
                    {
                        list = new ListItem(DataTableUtils.toString(row["err_type"]));
                        DropDownList_bad.Items.Add(list);
                    }
                }
            }
        }

        //設定廠區群組的下拉選單
        private void Set_Factory()
        {
            CNCError.Set_FactoryDropdownlist(acc, DropDownList_MachType, Request.FilePath);
        }

        //產生DataTable
        private void Set_Table()
        {
            if (HtmlUtil.Check_DataTable(dt_monthtotal))
            {
                DataTable dt_mach = dt_monthtotal.DefaultView.ToTable(true, new string[] { "設備代號" });
                if (HtmlUtil.Check_DataTable(dt_mach))
                    foreach (DataRow row in dt_mach.Rows)
                        mach += $"{row["設備代號"]}#";
                List<string> order_list = HtmlUtil.Comparison_ColumnOrder(columns, HtmlUtil.Get_ColumnsList(acc, System.IO.Path.GetFileName(Request.PhysicalPath).Split('.')[0]));
                th = HtmlUtil.Set_Table_Title(order_list, "style=\"vertical-align: middle; text-align: center;\"");
                tr = HtmlUtil.Set_Table_Content(true, dt_monthtotal, order_list, Enter_ReportView_callback);
            }
            else
                HtmlUtil.NoData(out th, out tr);
        }

        //例外處理
        private string Enter_ReportView_callback(DataRow row, string field_name)
        {
            string value = "";
            if (field_name == "工單報工")
            {
                string staff_information = "";
                List<string> staff_Number = new List<string>(DataTableUtils.toString(row["人員代號"]).Split('/'));
                List<string> staff_Name = new List<string>(DataTableUtils.toString(row["人員名稱"]).Split('/'));
                for (int i = 0; i < staff_Number.Count; i++)
                    staff_information += $"{staff_Number[i]}#{staff_Name[i]}#";
                string now_information = $"{row["設備名稱"]}^{row["工單號碼"]}^{row["品號"]}^{row["品名"]}^{row["預計產量"]}^{row["已生產量"]}^{row["今日產量"]}^{row["未生產量"]}^{DataTableUtils.toDouble(row["進度"]):0}%^{HtmlUtil.StrToDate(row["開工時間"].ToString()):yyyy/MM/dd HH:mm:ss}^{row["製程名稱"]}^{row["人員名稱"]}^";

                value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單報工"]}\" style=\"font - weight:normal;margin-bottom:0px \"><a href=\"javascript:void(0)\" ><img src=\"../../assets/images/canclick.png\"  width=\"50px\" height=\"50px\" data-toggle = \"modal\" data-target = \"#Report_Model\" onclick=Set_Information(\"{row["設備群組"]}\",\"{row["設備名稱"]}\",\"{row["工單狀態"]}\",\"{row["品號"]}\",\"{row["工單報工"]}\",\"{row["設備代號"]}\",\"{now_information.Replace(' ', '*')}\",\"{staff_information}\",\"{row["狀態"]}\") /></a></label>";
            }
            else if (field_name == "工單狀態")
            {
                if (DataTableUtils.toString(row["狀態"]) == "ERROR")
                    value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單報工"]}\" style=\"font - weight:normal;margin-bottom:0px \"><a href=\"javascript:void(0)\" ><img src=\"../../assets/images/Light_ExStopping.PNG\"  width=\"50px\" height=\"50px\"  /></a></label>";
                else if (DataTableUtils.toString(row["狀態"]) != "ERROR" && DataTableUtils.toString(row["狀態"]) != "")
                    value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單報工"]}\" style=\"font - weight:normal;margin-bottom:0px \"><a href=\"javascript:void(0)\" ><img src=\"../../assets/images/Light_Stopping.PNG\"  width=\"50px\" height=\"50px\"  /></a></label>";
                else
                    value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單報工"]}\" style=\"font - weight:normal;margin-bottom:0px \"><a href=\"javascript:void(0)\" ><img src=\"../../assets/images/Light_Running.png\"  width=\"50px\" height=\"50px\"  /></a></label>";
            }
            else if (field_name == "開工時間")
                value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單報工"]}\" style=\"font - weight:normal;margin-bottom:0px \">{HtmlUtil.StrToDate(row[field_name].ToString()):yyyy/MM/dd HH:mm:ss}</label>";
            else if (field_name == "進度")
                value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單報工"]}\" style=\"font - weight:normal;margin-bottom:0px \">{DataTableUtils.toDouble(row[field_name]):0}%</label>";
            else
                value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單報工"]}\" style=\"font - weight:normal;margin-bottom:0px \">{row[field_name]}</label>";
            return value == "" ? "" : $"<td align=\"center\" style=\"vertical-align:middle; color: black; \">{value}</td>";
        }

        //工單出站-良品
        private bool Order_Exit(DataTable dt_main, DataTable dt_other, double Report_Qty, string now_time)
        {
            bool ok = true;
            int count = 0;
            int total = dt_main.Rows.Count;
            foreach (DataRow row in dt_main.Rows)
            {
                //目標數量  50
                double target_qty = DataTableUtils.toInt(DataTableUtils.toString(row["exp_product_count_day"]));

                //已生產數量 0
                double producted_qty = DataTableUtils.toInt(DataTableUtils.toString(row["product_count_day"]));
                //剩餘數量 回報數量+已生產數量-目標數量
                double last_qty = Report_Qty + producted_qty - target_qty;

                if (last_qty >= 0)
                    Report_Qty = last_qty;

                if ((dt_other == null || dt_other.Rows.Count == 0) && count == total - 1 && Report_Qty >= 0 && last_qty >= 0)
                    target_qty = target_qty + Report_Qty;

                DataRow rows = dt_main.NewRow();
                rows["_id"] = row["_id"];

                rows["product_count_day"] = last_qty >= 0 ? target_qty : producted_qty + Report_Qty;
                rows["no_product_count_day"] = last_qty >= 0 ? 0 : target_qty - (producted_qty + Report_Qty);
                rows["good_qty"] = last_qty >= 0 ? target_qty - producted_qty + DataTableUtils.toDouble(row["good_qty"]) : Report_Qty + DataTableUtils.toDouble(row["good_qty"]);

                rows["last_updatetime"] = now_time;
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                if (DataTableUtils.Update_DataRow("workorder_information", $"mach_name='{row["mach_name"]}'  and manu_id='{row["manu_id"]}' and type_mode='進站報工'", rows))
                {
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    string sqlcmd = $"SELECT * FROM (SELECT *, (SELECT MIN(a.now_time) FROM record_worktime a WHERE workman_status = '出站' AND a.mach_name = record_worktime.mach_name AND a.work_staff = record_worktime.work_staff AND a.now_time >= record_worktime.now_time AND a.manu_id = record_worktime.manu_id) exit_time FROM record_worktime WHERE workman_status = '入站') a WHERE a.exit_time IS NULL AND product_number = '{row["product_number"]}' AND mach_name = '{row["mach_name"]}' AND now_time <= '{now_time}' AND manu_id = '{row["manu_id"]}' and type_mode = '進站報工'";
                    DataTable dt_insert = DataTableUtils.GetDataTable(sqlcmd);
                    if (HtmlUtil.Check_DataTable(dt_insert))
                    {
                        DataTable dt_clone = dt_insert.Clone();
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                        sqlcmd = "SELECT max(_id) _id FROM record_worktime";
                        DataTable dt_max = DataTableUtils.GetDataTable(sqlcmd);
                        int max = HtmlUtil.Check_DataTable(dt_max) ? DataTableUtils.toInt(dt_max.Rows[0]["_id"].ToString()) + 1 : 1;
                        int j = 0;
                        foreach (DataRow dtrow in dt_insert.Rows)
                        {
                            rows = dt_clone.NewRow();
                            rows["_id"] = max + j;
                            rows["mach_name"] = dtrow["mach_name"];

                            rows["manu_id"] = dtrow["manu_id"];
                            rows["product_number"] = dtrow["product_number"];
                            rows["product_name"] = dtrow["product_name"];
                            rows["work_staff"] = dtrow["work_staff"];
                            rows["workman_status"] = "良品出站";
                            rows["report_qty"] = last_qty >= 0 ? target_qty - producted_qty : Report_Qty;
                            rows["qty_status"] = "良品";
                            rows["now_time"] = now_time;
                            rows["type_mode"] = "進站報工";
                            dt_clone.Rows.Add(rows);
                            j++;
                        }
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                        if (dt_clone.Rows.Count == DataTableUtils.Insert_TableRows("record_worktime", dt_clone))
                        {
                            ok = true;
                            count++;
                            if (dt_other != null)
                            {
                                if (last_qty >= 0)
                                    Order_Exit(dt_other, null, Report_Qty, now_time);
                                else
                                    Order_Exit(dt_other, null, 0, now_time);
                            }

                            if (dt_other == null && last_qty < 0)
                                Report_Qty = 0;
                        }
                        else
                            return false;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            return ok;
        }

        //工單出站-不良品
        private bool Bad_Exit(DataTable dt_main, DataTable dt_other, double Bad_Qty, string now_time, List<string> list = null)
        {
            bool ok = true;
            bool judge = false;
            int count = 0;
            int total = dt_main.Rows.Count;
            double bad_copy = Bad_Qty;
            double bad_total = 0;
            list = list == null ? new List<string>(TextBox_BadInformation.Text.Split('#')) : list;

            foreach (DataRow row in dt_main.Rows)
            {
                //目標數量 --50
                double target_qty = DataTableUtils.toInt(DataTableUtils.toString(row["exp_product_count_day"]));

                //已生產數量 --40
                double producted_qty = DataTableUtils.toInt(DataTableUtils.toString(row["product_count_day"]));

                //未生產數量 --10
                double unproducted_qty = target_qty - producted_qty;

                //剩餘不良數量 --0
                double last_qty = unproducted_qty >= 0 ? Bad_Qty - unproducted_qty : Bad_Qty;

                // --10
                if (last_qty >= 0)
                    Bad_Qty = last_qty;

                if ((dt_other == null || dt_other.Rows.Count == 0) && count == total - 1 && Bad_Qty >= 0 && last_qty >= 0)
                    target_qty = target_qty + Bad_Qty;

                if ((dt_other == null || dt_other.Rows.Count == 0) && count == total - 1)
                    judge = true;
                DataRow rows = dt_main.NewRow();
                rows["_id"] = row["_id"];

                //未生產量
                rows["no_product_count_day"] = last_qty >= 0 ? 0 : target_qty - (producted_qty + Bad_Qty);

                //不良品數量
                rows["bad_qty"] = last_qty >= 0 ? judge ? bad_copy : unproducted_qty : Bad_Qty;

                //預計產量
                rows["product_count_day"] = DataTableUtils.toDouble(rows["bad_qty"].ToString()) + producted_qty;
                //判斷存入的數量
                bad_total = last_qty >= 0 ? judge ? bad_copy : unproducted_qty : Bad_Qty;

                rows["last_updatetime"] = now_time;
                rows["order_status"] = "出站";

                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                if (DataTableUtils.Update_DataRow("workorder_information", $"mach_name='{row["mach_name"]}'  and manu_id='{row["manu_id"]}' and type_mode='進站報工' ", rows))
                {
                    //填入不良品
                    if (bad_total > 0)
                        Bad_Add(row, list, bad_total);
                    //填入 record_worktime
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    string sqlcmd = $"SELECT * FROM (SELECT *, (SELECT MIN(a.now_time) FROM record_worktime a WHERE workman_status = '出站' AND a.mach_name = record_worktime.mach_name AND a.work_staff = record_worktime.work_staff AND a.now_time >= record_worktime.now_time AND a.manu_id = record_worktime.manu_id) exit_time FROM record_worktime WHERE workman_status = '入站') a WHERE a.exit_time IS NULL AND product_number = '{row["product_number"]}' AND mach_name = '{row["mach_name"]}' AND now_time <= '{now_time}' AND manu_id = '{row["manu_id"]}' and type_mode = '進站報工'   ";
                    DataTable dt_insert = DataTableUtils.GetDataTable(sqlcmd);
                    if (HtmlUtil.Check_DataTable(dt_insert))
                    {
                        DataTable dt_clone = dt_insert.Clone();
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                        sqlcmd = "SELECT max(_id) _id FROM record_worktime";
                        DataTable dt_max = DataTableUtils.GetDataTable(sqlcmd);
                        int max = HtmlUtil.Check_DataTable(dt_max) ? DataTableUtils.toInt(dt_max.Rows[0]["_id"].ToString()) + 1 : 1;
                        int j = 0;
                        foreach (DataRow dtrow in dt_insert.Rows)
                        {
                            rows = dt_clone.NewRow();
                            rows["_id"] = max + j;
                            rows["mach_name"] = dtrow["mach_name"];
                            rows["manu_id"] = dtrow["manu_id"];
                            rows["product_number"] = dtrow["product_number"];
                            rows["product_name"] = dtrow["product_name"];
                            rows["work_staff"] = dtrow["work_staff"];
                            rows["workman_status"] = "出站";
                            rows["report_qty"] = last_qty >= 0 ? judge ? bad_copy : unproducted_qty : Bad_Qty;
                            rows["qty_status"] = "不良品";
                            rows["now_time"] = now_time;
                            rows["type_mode"] = "進站報工";
                            dt_clone.Rows.Add(rows);
                            j++;
                        }
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                        if (dt_clone.Rows.Count == DataTableUtils.Insert_TableRows("record_worktime", dt_clone))
                        {
                            ok = true;
                            count++;
                            if (dt_other != null)
                            {
                                if (last_qty >= 0)
                                    Bad_Exit(dt_other, null, Bad_Qty, now_time, list);
                                else
                                    Bad_Exit(dt_other, null, 0, now_time, list);
                            }

                            if (dt_other == null && last_qty < 0)
                                Bad_Qty = 0;
                        }
                        else
                            return false;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            return ok;
        }
        
        //填入不良品
        private List<string> Bad_Add(DataRow row, List<string> list, double bad_qty)
        {
            double bad_copy = bad_qty;
            //15
            double count = DataTableUtils.toDouble(list[1]);

            bad_qty = bad_qty - count >= 0 ? count : bad_qty;

            //取得結構
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = "select * from bad_total";
            DataTable dt_Bad = DataTableUtils.GetDataTable(sqlcmd);

            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            sqlcmd = "select max(id) id from bad_total";
            DataTable dt_max = DataTableUtils.GetDataTable(sqlcmd);

            int max = HtmlUtil.Check_DataTable(dt_max) ? DataTableUtils.toInt(dt_max.Rows[0]["id"].ToString()) + 1 : 1;

            DataRow rows = dt_Bad.NewRow();
            rows["id"] = max;
            rows["mach_name"] = row["mach_name"];
            rows["manu_id"] = row["manu_id"];
            rows["now_time"] = DateTime.Now.ToString("yyyyMMddHHmmss");
            rows["bad_qty"] = bad_qty;
            rows["exp_product_count_day"] = row["exp_product_count_day"];
            rows["work_staff"] = row["history_workstaff"];
            rows["type_mode"] = "進站報工";
            rows["product_number"] = row["product_number"];
            rows["delivery"] = row["delivery"];
            rows["bad_type"] = list[0];
            rows["bad_content"] = list[2];
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            if (DataTableUtils.Insert_DataRow("bad_total", rows))
            {
                //數量不足
                if ((bad_copy - count) > 0)
                {
                    list.RemoveAt(0);
                    list.RemoveAt(0);
                    list.RemoveAt(0);
                    if (list.Count > 2)
                        Bad_Add(row, list, bad_copy - count);
                    else
                        return null;
                }
                //數量足夠 還可以回扣
                else if ((bad_copy - count) < 0)
                {
                    list[1] = (count - bad_qty).ToString();
                    return list;
                }
                else
                {
                    list.RemoveAt(0);
                    list.RemoveAt(0);
                    list.RemoveAt(0);
                    return list;
                }
            }
            return list;
        }

        //把維護數量加至報工數量
        private void Maintain_to_Report()
        {
            //先找到報工的
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = "SELECT  * FROM workorder_information WHERE copy_maintain IS NULL AND order_status = '入站' AND type_mode = '進站報工'";
            DataTable dt_report = DataTableUtils.GetDataTable(sqlcmd);

            if (HtmlUtil.Check_DataTable(dt_report))
            {
                //依據報工找到派工
                string manu_id = "";
                foreach (DataRow row in dt_report.Rows)
                    manu_id += manu_id == "" ? $" manu_id='{row["manu_id"]}' " : $" or manu_id='{row["manu_id"]}'";

                if (manu_id != "")
                {
                    manu_id = $" and ( {manu_id} ) ";
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    sqlcmd = $"SELECT  * FROM workorder_information WHERE  order_status = '出站' AND type_mode = '進站維護' {manu_id}";
                    DataTable dt_maintain = DataTableUtils.GetDataTable(sqlcmd);
                    if (HtmlUtil.Check_DataTable(dt_maintain))
                    {
                        foreach (DataRow row in dt_report.Rows)
                        {
                            DataRow[] rows = dt_maintain.Select($"manu_id='{row["manu_id"]}'");
                            if (rows != null && rows.Length > 0)
                            {
                                DataRow rsw = dt_report.NewRow();
                                rsw["product_count_day"] = rows[0]["product_count_day"];
                                rsw["no_product_count_day"] = DataTableUtils.toDouble(row["no_product_count_day"].ToString()) - DataTableUtils.toDouble(rows[0]["good_qty"].ToString());
                                rsw["maintain_qty"] = DataTableUtils.toDouble(rows[0]["good_qty"].ToString());
                                rsw["copy_maintain"] = "Y";
                                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                                DataTableUtils.Update_DataRow("workorder_information", $"manu_id='{row["manu_id"]}' and type_mode='進站報工'", rsw);
                            }
                        }
                    }
                }
            }
        }

        //透過POST的方式，把資料傳入ERP內
        static async void PostToERP(string order, string machine)
        {
            string ss = "";
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);

            string sqlcmd = $"SELECT  " +
                            $"      'BBE' cus,  " +
                            $"      'TEST' Company,  " + //需修改
                            $"      SUBSTRING_INDEX(_id, '-', 1) NO, " +
                            $"      SUBSTRING_INDEX( SUBSTRING_INDEX(_id, '-', 2), '-', -1) `Order`, " +
                            $"      SUBSTRING_INDEX(_id, '-', -1) ProcessSeq, " +
                            $"      mach_name Vendor_ID, " +
                            $"      craft_Number  ProcessCode, " +
                            $"      product_number ItemNum, " +
                            $"      product_name ItemName1, " +
                            $"      specification ItemName2," +
                            $"      CONVERT((IFNULL(good_qty,0) +IFNULL( maintain_qty,0)),char)  P_Qty, " +
                            $"      bad_qty N_Qty, " +
                            $"      '0' P_Time, " + //需修改
                            $"      '0' M_Time, " + //需修改
                            $"      DATE_FORMAT(now_time, '%Y-%m-%d %H:%i:%s') S_date, " +
                            $"      DATE_FORMAT(last_updatetime, '%Y%m%d') E_date " +
                            $"  FROM workorder_information " +
                            $"  where manu_id='{order}' and mach_name = '{machine}' and type_mode='進站報工'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

            List<Post_Order> od = HtmlUtil.ConvertToList<Post_Order>(dt);

            var httpClient = new HttpClient();
            var json = JsonConvert.SerializeObject(od);
            HttpContent httpContent = new StringContent(json);
            httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            HttpResponseMessage response = null;
            response = await httpClient.PostAsync(HtmlUtil.Get_Ini("Parameter", "post_api",""), httpContent);

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadAsStringAsync();
                if (result.Contains("ERROR"))
                    ss = "可以抓到錯誤內容";
                else if (result.Contains("PASS"))
                    ss = "傳送成功";
            }

        }
    }
}