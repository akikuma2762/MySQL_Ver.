﻿using dek_erpvis_v2.cls;
using Support;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace dek_erpvis_v2.pages.dp_CNC
{
    public partial class Report_Type : System.Web.UI.Page
    {
        public string color = "";
        string acc = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            //確保能從前端成功讀取API
            Response.AppendHeader("Access-Control-Allow-Origin", "*");
            Response.AppendHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
            Response.AppendHeader("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE");
            //確保能從前端成功讀取API
            HttpCookie userInfo = Request.Cookies["userInfo"];
            if (userInfo != null)
            {
                acc = DataTableUtils.toString(userInfo["user_ACC"]);
                color = HtmlUtil.change_color(acc);
            }
            else
                Response.Redirect("../login.aspx");
        }

        protected void Button_Save_Click(object sender, EventArgs e)
        {
            List<string> machine_list = new List<string>(TextBox_SaveMachine.Text.Split('#'));
            List<string> order_list = new List<string>(TextBox_SaveOrder.Text.Split('#'));
            List<string> allorder_list = new List<string>(TextBox_SaveAllOrder.Text.Split('#'));
            List<string> staff_list = new List<string>(TextBox_SaveStaff.Text.Split('#'));

            //確定輸入的工單數量
            int order_count = (allorder_list.Count - 1) / 9;

            //確認入站人員
            string Enter_Staff = "";
            string Enter_StaffNumber = "";
            for (int i = 0; i < staff_list.Count - 1; i++)
            {
                if (i % DataTableUtils.toInt(WebUtils.GetAppSettings("Staff_Length")) == 1)
                    Enter_Staff += Enter_Staff == "" ? staff_list[i] : $"/{staff_list[i]}";
                if (i % DataTableUtils.toInt(WebUtils.GetAppSettings("Staff_Length")) == 0)
                    Enter_StaffNumber += Enter_StaffNumber == "" ? staff_list[i] : $"/{staff_list[i]}";
            }

            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = "select * from aps_list_info";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            List<bool> ok = new List<bool>();
            if (dt != null)
            {
                for (int i = 0; i < order_count; i++)
                {
                    int orders = i * (DataTableUtils.toInt(WebUtils.GetAppSettings("Array_Length")) / 2 + 1);
                    DataRow row = dt.NewRow();
                    //工單序號
                    row["_id"] = allorder_list[orders];
                    //機台名稱
                    row["mach_name"] = machine_list[0];
                    //群組名稱
                    row["group_name"] = machine_list[1];
                    //機台實顯名稱
                    row["mach_show_name"] = machine_list[2];
                    //料號
                    row["product_number"] = allorder_list[orders + 1];
                    //品名
                    row["product_name"] = allorder_list[orders + 2];
                    //預計生產數量
                    row["exp_product_count_day"] = allorder_list[orders + 3];
                    //已完成數量
                    row["product_count_day"] = allorder_list[orders + 4];
                    //未完成量
                    row["no_product_count_day"] = allorder_list[orders + 5];
                    //製程編號
                    row["craft_Number"] = allorder_list[orders + 6];
                    //製程名稱
                    row["craft_name"] = allorder_list[orders + 7];
                    //工單狀態
                    row["order_status"] = order_list.IndexOf(allorder_list[orders]) != -1 && order_list.IndexOf(allorder_list[orders + 1]) != -1 ? "入站" : "";
                    //現在時間
                    row["now_time"] = DateTime.Now.ToString("yyyyMMddHHmmss");
                    //員工代號
                    row["staff_Number"] = order_list.IndexOf(allorder_list[orders]) != -1 && order_list.IndexOf(allorder_list[orders + 1]) != -1 ? Enter_StaffNumber : "";
                    //員工姓名
                    row["work_staff"] = order_list.IndexOf(allorder_list[orders]) != -1 && order_list.IndexOf(allorder_list[orders + 1]) != -1 ? Enter_Staff : "";

                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    ok.Add(allorder_list[orders + 8] == "insert" ? DataTableUtils.Insert_DataRow("aps_list_info", row) : DataTableUtils.Update_DataRow("aps_list_info", $"_id={allorder_list[orders]}", row));
                }
                if (ok.IndexOf(false) == -1)
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('已新增成功{ok.Count}筆');location.href='Report_Type.aspx';</script>");
                else
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('新增異常');location.href='Report_Type.aspx';</script>");

            }
        }
    }
}