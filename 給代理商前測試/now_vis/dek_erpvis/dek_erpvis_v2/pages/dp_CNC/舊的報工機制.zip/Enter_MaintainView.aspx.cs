﻿using dek_erpvis_v2.cls;
using dek_erpvis_v2.webservice;
using dekERP_dll.dekErp;
using Support;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace dek_erpvis_v2.pages.dp_CNC
{
    public partial class Enter_MaintainView : System.Web.UI.Page
    {
        //引用 OR 參數
        ERP_cnc CNC = new ERP_cnc();
        public string color = "";
        public string path = "";
        string acc = "";
        public StringBuilder tr = new StringBuilder();
        public StringBuilder th = new StringBuilder();
        DataTable dt_monthtotal = new DataTable();
        List<string> columns = new List<string>();
        public string mach = "";
        List<string> machlist = new List<string>();
        myclass myclass = new myclass();
        //載入事件
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie userInfo = Request.Cookies["userInfo"];
            if (userInfo != null)
            {
                acc = DataTableUtils.toString(userInfo["user_ACC"]);
                path = 德大機械.get_title_web_path("DES");
                color = HtmlUtil.change_color(acc);

                if (HtmlUtil.check_power(acc, System.IO.Path.GetFileName(Request.PhysicalPath).Split('.')[0]) || myclass.user_view_check(System.IO.Path.GetFileName(Request.PhysicalPath).Split('.')[0], acc))
                {
                    if (!IsPostBack)
                        MainProcess();
                }
                else
                    Response.Write("<script>alert('您無此權限!');location.href='../index.aspx';</script>");
            }
            else
                Response.Redirect(myclass.logout_url);
        }

        //暫停事件
        protected void Button_Save_Click(object sender, EventArgs e)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"select * from (  SELECT  *, (SELECT  MIN(a.now_time) FROM record_worktime a WHERE workman_status = '出站'  AND a.mach_name = record_worktime.mach_name AND a.work_staff = record_worktime.work_staff AND a.now_time >= record_worktime.now_time AND a.manu_id = record_worktime.manu_id) exit_time FROM record_worktime WHERE workman_status = '入站') a where a.exit_time IS null and product_number='{TextBox_Number.Text}' and mach_name='{TextBox_Machine.Text}'  and now_time <='{DateTime.Now:yyyyMMddHHmmss}' ";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

            if (HtmlUtil.Check_DataTable(dt))
            {
                DataTable dt_clone = dt.Clone();
                int j = 0;
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = "SELECT max(_id) _id FROM record_worktime";
                DataTable dt_max = DataTableUtils.GetDataTable(sqlcmd);
                int max = HtmlUtil.Check_DataTable(dt_max) ? DataTableUtils.toInt(dt_max.Rows[0]["_id"].ToString()) + 1 : 1;
                string now_time = DateTime.Now.ToString("yyyyMMddHHmmss");
                //紀錄暫停原因跟類型
                foreach (DataRow row in dt.Rows)
                {
                    DataRow rows = dt_clone.NewRow();
                    rows["_id"] = max + j;
                    rows["mach_name"] = row["mach_name"];
                    rows["manu_id"] = row["manu_id"];
                    rows["product_number"] = row["product_number"];
                    rows["product_name"] = row["product_name"];
                    rows["work_staff"] = row["work_staff"];
                    rows["workman_status"] = "暫停";
                    rows["report_qty"] = "0";
                    rows["qty_status"] = "良品";
                    rows["now_time"] = now_time;
                    rows["stop_type"] = DropDownList_StopType.SelectedItem.Text;
                    rows["stop_reason"] = TextBox_content.Text;
                    rows["type_mode"] = "進站維護";
                    dt_clone.Rows.Add(rows);
                    j++;
                }
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                if (dt_clone.Rows.Count == DataTableUtils.Insert_TableRows("record_worktime", dt_clone))
                {
                    //更新狀態
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}' and product_number='{TextBox_Number.Text}'";
                    dt = DataTableUtils.GetDataTable(sqlcmd);
                    if (HtmlUtil.Check_DataTable(dt))
                    {
                        List<bool> ok = new List<bool>();
                        foreach (DataRow row in dt.Rows)
                        {
                            DataRow rows = dt.NewRow();
                            rows["_id"] = row["_id"];
                            rows["order_status"] = "暫停";
                            rows["last_updatetime"] = now_time;
                            rows["error_type"] = DropDownList_StopType.SelectedItem.Text;
                            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                            ok.Add(DataTableUtils.Update_DataRow("workorder_information", $"mach_name='{TextBox_Machine.Text}' and product_number='{TextBox_Number.Text}' and manu_id='{row["manu_id"]}'", rows));
                        }
                        if (ok.IndexOf(false) == -1)
                            Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存成功');location.href='Enter_MaintainView.aspx';</script>");
                        else
                            Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_MaintainView.aspx';</script>");
                    }
                }
                else
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_MaintainView.aspx';</script>");
            }
        }

        //取消暫停事件
        protected void Button_Cancel_Click(object sender, EventArgs e)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"SELECT  * FROM (SELECT  *, (SELECT  MIN(a.now_time) FROM record_worktime a WHERE workman_status = '取消暫停' AND a.mach_name = record_worktime.mach_name AND a.work_staff = record_worktime.work_staff AND a.now_time >= record_worktime.now_time AND a.manu_id = record_worktime.manu_id) cancel_time FROM record_worktime WHERE workman_status = '暫停') a WHERE a.cancel_time IS NULL  and product_number='{TextBox_Number.Text}' and mach_name='{TextBox_Machine.Text}'  and now_time <='{DateTime.Now:yyyyMMddHHmmss}'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

            if (HtmlUtil.Check_DataTable(dt))
            {
                DataTable dt_clone = dt.Clone();
                int j = 0;
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = "SELECT max(_id) _id FROM record_worktime";
                DataTable dt_max = DataTableUtils.GetDataTable(sqlcmd);
                int max = HtmlUtil.Check_DataTable(dt_max) ? DataTableUtils.toInt(dt_max.Rows[0]["_id"].ToString()) + 1 : 1;
                string now_time = DateTime.Now.ToString("yyyyMMddHHmmss");
                //紀錄暫停原因跟類型
                foreach (DataRow row in dt.Rows)
                {
                    DataRow rows = dt_clone.NewRow();
                    rows["_id"] = max + j;
                    rows["mach_name"] = row["mach_name"];
                    rows["manu_id"] = row["manu_id"];
                    rows["product_number"] = row["product_number"];
                    rows["product_name"] = row["product_name"];
                    rows["work_staff"] = row["work_staff"];
                    rows["workman_status"] = "取消暫停";
                    rows["report_qty"] = "0";
                    rows["qty_status"] = "良品";
                    rows["now_time"] = now_time;
                    rows["type_mode"] = "進站維護";
                    dt_clone.Rows.Add(rows);
                    j++;
                }
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                if (dt_clone.Rows.Count == DataTableUtils.Insert_TableRows("record_worktime", dt_clone))
                {
                    //更新狀態
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}' and product_number='{TextBox_Number.Text}'";
                    dt = DataTableUtils.GetDataTable(sqlcmd);
                    if (HtmlUtil.Check_DataTable(dt))
                    {
                        List<bool> ok = new List<bool>();
                        foreach (DataRow row in dt.Rows)
                        {
                            DataRow rows = dt.NewRow();
                            rows["_id"] = row["_id"];
                            rows["order_status"] = "入站";
                            rows["last_updatetime"] = now_time;
                            rows["error_type"] = "";
                            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                            ok.Add(DataTableUtils.Update_DataRow("workorder_information", $"mach_name='{TextBox_Machine.Text}' and product_number='{TextBox_Number.Text}' and manu_id='{row["manu_id"]}'", rows));
                        }
                        if (ok.IndexOf(false) == -1)
                            Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存成功');location.href='Enter_MaintainView.aspx';</script>");
                        else
                            Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_MaintainView.aspx';</script>");
                    }
                }
                else
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_MaintainView.aspx';</script>");
            }
        }

        //跳頁
        protected void Button_jump_Click(object sender, EventArgs e)
        {
            List<string> list = new List<string>(TextBox_Staffs.Text.Split('#'));
            string staff = "";
            for (int i = 0; i < list.Count - 1; i++)
            {
                i++;
                staff += staff == "" ? list[i] : $"/{list[i]}";
            }
            string url = $"machine={TextBox_Machine.Text},number={TextBox_Number.Text},order={TextBox_Order.Text},show_name={TextBox_Show.Text},group={TextBox_Group.Text},type=進站維護,staff={staff}";
            Response.Redirect($"Error_Detail.aspx?key={WebUtils.UrlStringEncode(url)}");
        }

        //工單出站
        protected void Button_Exit_Click(object sender, EventArgs e)
        {
            //主要的報工之DATATABLE
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}'  and manu_id='{TextBox_Order.Text}' and type_mode='進站維護'";
            DataTable dt_main = DataTableUtils.GetDataTable(sqlcmd);

            //若有多的會往這邊扣除之DATATABLE
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            sqlcmd = $"select * from workorder_information where mach_name='{TextBox_Machine.Text}'  and manu_id <> '{TextBox_Order.Text}' and type_mode='進站維護'  and order_status ='入站' order by delivery asc";
            DataTable dt_secondary = DataTableUtils.GetDataTable(sqlcmd);

            string now_time = DateTime.Now.ToString("yyyyMMddHHmmss");
            if (HtmlUtil.Check_DataTable(dt_main) && dt_secondary != null)
            {
                ////填寫不良
                double bad_qty = DataTableUtils.toDouble(TextBox_badqty.Text) * DataTableUtils.toDouble(DataTableUtils.toString(dt_main.Rows[0]["division"])) / DataTableUtils.toDouble(DataTableUtils.toString(dt_main.Rows[0]["multiplication"]));
                BadQty_Record(dt_main, bad_qty, now_time, TextBox_BadInformation.Text);

                //維護不用加上不良
                double qty = DataTableUtils.toDouble(TextBox_Good.Text) * DataTableUtils.toDouble(DataTableUtils.toString(dt_main.Rows[0]["division"])) / DataTableUtils.toDouble(DataTableUtils.toString(dt_main.Rows[0]["multiplication"]));

                bool ok = Order_Exit(dt_main, dt_secondary, qty, now_time);
                if (ok)
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存成功');location.href='Enter_MaintainView.aspx';</script>");
                else
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_MaintainView.aspx';</script>");
            }
            else
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_MaintainView.aspx';</script>");
        }

        //欄位移動事件儲存
        protected void Button_SaveColumns_Click(object sender, EventArgs e)
        {
            HtmlUtil.Save_Columns(TextBox_SaveColumn.Text, System.IO.Path.GetFileName(Request.PhysicalPath).Split('.')[0], acc);
        }

        //選取顯示欄位與廠區群組
        protected void Button_Check_Click(object sender, EventArgs e)
        {
            //儲存需顯示之欄位
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"select * from show_column where Account='{acc}' and use_page='Enter_MaintainView'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            if (dt != null)
            {
                //先刪除裡面的資料
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                DataTableUtils.Delete_Record("show_column", $"Account='{acc}' and use_page='Enter_MaintainView'");

                //取得最大ID
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = "SELECT max(ID) ID FROM show_column";
                DataTable dt_max = DataTableUtils.GetDataTable(sqlcmd);
                int max = HtmlUtil.Check_DataTable(dt_max) ? DataTableUtils.toInt(dt_max.Rows[0]["ID"].ToString()) + 1 : 1;

                DataTable dt_clone = dt.Clone();
                for (int i = 0; i < CheckBoxList_Columns.Items.Count; i++)
                {
                    DataRow row = dt_clone.NewRow();
                    row["id"] = max + i;
                    row["Column_Name"] = CheckBoxList_Columns.Items[i].Text == "工單維護" ? "工單報工" : CheckBoxList_Columns.Items[i].Text;
                    row["Account"] = acc;
                    row["Allow"] = CheckBoxList_Columns.Items[i].Selected ? "True" : "False";
                    row["use_page"] = "Enter_MaintainView";
                    dt_clone.Rows.Add(row);
                }
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                if (DataTableUtils.Insert_TableRows("show_column", dt_clone) == dt_clone.Rows.Count)
                {
                    DropDownList_MachType.SelectedIndex = DropDownList_MachType.Items.IndexOf(DropDownList_MachType.Items.FindByValue(TextBox_MachTypeValue.Text));
                    DropDownList_MachGroup.Items.Clear();
                    List<string> list = new List<string>(TextBox_MachTypeValue.Text.Split(','));
                    for (int i = 0; i < list.Count - 1; i++)
                    {
                        ListItem listItem = new ListItem(list[i], list[i + 1]);
                        DropDownList_MachGroup.Items.Add(listItem);
                        i++;
                    }
                    DropDownList_MachGroup.SelectedIndex = DropDownList_MachGroup.Items.IndexOf(DropDownList_MachGroup.Items.FindByText(TextBox_MachGroupText.Text));
                    machlist = new List<string>(TextBox_Machines.Text.Split(','));
                    MainProcess();
                }
                else
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_MaintainView.aspx';</script>");
            }
            else
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", $"<script>alert('儲存失敗');location.href='Enter_MaintainView.aspx';</script>");
        }

        //須執行之副程式
        private void MainProcess()
        {
            Set_Dropdownlist();
            Set_Factory();
            Set_Checkbox();
            Get_MonthTotal();
            Set_Table();
        }

        //取得目前所有的狀態為未出站的資料
        private void Get_MonthTotal()
        {
            if (machlist.Count > 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                string sqlcmd = "select * from machine_info";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
                if (HtmlUtil.Check_DataTable(dt))
                {
                    for (int i = 0; i < machlist.Count; i++)
                    {
                        DataRow[] rows = dt.Select($"mach_show_name='{machlist[i]}'");
                        if (rows != null && rows.Length > 0)
                            machlist[i] = DataTableUtils.toString(rows[0]["mach_name"]);
                    }
                }
            }
            dt_monthtotal = CNC.Enter_MaintainView("cnc", machlist);
        }

        //設定核取方塊
        private void Set_Checkbox()
        {
            CheckBoxList_Columns.Items.Clear();
            //找到系統預設的
            DataTable dt_System = CNC.System_columns("Enter_MaintainView");
            //找到個人設定的
            DataTable dt_Person = CNC.Person_columns("Enter_MaintainView", acc);

            //個人的
            if (HtmlUtil.Check_DataTable(dt_System))
            {
                ListItem listItem = new ListItem();
                //個人的
                if (HtmlUtil.Check_DataTable(dt_Person))
                {
                    foreach (DataRow row in dt_System.Rows)
                    {
                        string column = DataTableUtils.toString(row["info_chinese"]) == "工單報工" ? "工單維護" : DataTableUtils.toString(row["info_chinese"]);

                        listItem = new ListItem(column, DataTableUtils.toString(row["info_name"]));
                        var select = dt_Person.AsEnumerable().Where(w => w.Field<string>("info_name") == DataTableUtils.toString(row["info_name"]));
                        if (select.FirstOrDefault() != null)
                        {
                            listItem.Selected = true;
                            columns.Add(column);
                        }
                        CheckBoxList_Columns.Items.Add(listItem);
                    }
                }
                //系統的
                else
                {
                    foreach (DataRow row in dt_System.Rows)
                    {
                        string column = DataTableUtils.toString(row["info_chinese"]) == "工單報工" ? "工單維護" : DataTableUtils.toString(row["info_chinese"]);

                        listItem = new ListItem(column, DataTableUtils.toString(row["info_name"]));
                        listItem.Selected = true;
                        columns.Add(column);
                        CheckBoxList_Columns.Items.Add(listItem);
                    }
                }

                columns.Add("");
            }

        }

        //設定異常類型
        private void Set_Dropdownlist()
        {
            if (DropDownList_StopType.Items.Count == 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                string sqlcmd = "select * from error_type where err_type_title = '暫停類型' and err_type <> 'ERROR'";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
                if (HtmlUtil.Check_DataTable(dt))
                {
                    DropDownList_StopType.Items.Clear();
                    ListItem list = new ListItem();
                    foreach (DataRow row in dt.Rows)
                    {
                        list = new ListItem(DataTableUtils.toString(row["err_type"]));
                        DropDownList_StopType.Items.Add(list);
                    }
                    list = new ListItem("ERROR");
                    DropDownList_StopType.Items.Add(list);
                }
            }

            if (DropDownList_bad.Items.Count == 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                string sqlcmd = "select * from error_type where err_type_title = '不良類型'";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                if (HtmlUtil.Check_DataTable(dt))
                {
                    DropDownList_bad.Items.Clear();
                    ListItem list = new ListItem();
                    list = new ListItem("");
                    DropDownList_bad.Items.Add(list);
                    foreach (DataRow row in dt.Rows)
                    {
                        list = new ListItem(DataTableUtils.toString(row["err_type"]));
                        DropDownList_bad.Items.Add(list);
                    }

                }
            }
        }

        //設定廠區群組的下拉選單
        private void Set_Factory()
        {
            CNCError.Set_FactoryDropdownlist(acc, DropDownList_MachType, Request.FilePath);
        }

        //產生DataTable
        private void Set_Table()
        {
            if (HtmlUtil.Check_DataTable(dt_monthtotal))
            {
                DataTable dt_mach = dt_monthtotal.DefaultView.ToTable(true, new string[] { "設備代號" });
                if (HtmlUtil.Check_DataTable(dt_mach))
                    foreach (DataRow row in dt_mach.Rows)
                        mach += $"{row["設備代號"]}#";

                List<string> order_list = HtmlUtil.Comparison_ColumnOrder(columns, HtmlUtil.Get_ColumnsList(acc, System.IO.Path.GetFileName(Request.PhysicalPath).Split('.')[0]));

                th = HtmlUtil.Set_Table_Title(order_list, "style=\"vertical-align: middle; text-align: center;\"");
                tr = HtmlUtil.Set_Table_Content(true, dt_monthtotal, order_list, Enter_MaintainView_callback);
            }
            else
                HtmlUtil.NoData(out th, out tr);
        }

        //例外處理
        private string Enter_MaintainView_callback(DataRow row, string field_name)
        {
            string value = "";
            if (field_name == "工單維護")
            {
                string staff_information = "";
                List<string> staff_Number = new List<string>(DataTableUtils.toString(row["人員代號"]).Split('/'));
                List<string> staff_Name = new List<string>(DataTableUtils.toString(row["人員名稱"]).Split('/'));
                for (int i = 0; i < staff_Number.Count; i++)
                    staff_information += $"{staff_Number[i]}#{staff_Name[i]}#";
                string now_information = $"{row["設備名稱"]}^{row["工單號碼"]}^{row["品號"]}^{row["品名"]}^{row["預計產量"]}^{row["已生產量"]}^{row["今日產量"]}^{row["未生產量"]}^{DataTableUtils.toDouble(row["進度"]):0}%^{HtmlUtil.StrToDate(row["開工時間"].ToString()):yyyy/MM/dd HH:mm:ss}^{row["製程名稱"]}^{row["人員名稱"]}^";

                value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單維護"]}\" style=\"font - weight:normal;margin-bottom:0px \"><a href=\"javascript:void(0)\" ><img src=\"../../assets/images/canclick.png\"  width=\"50px\" height=\"50px\" data-toggle = \"modal\" data-target = \"#Report_Model\" onclick=Set_Information(\"{row["設備群組"]}\",\"{row["設備名稱"]}\",\"{row["工單狀態"]}\",\"{row["品號"]}\",\"{row["工單維護"]}\",\"{row["設備代號"]}\",\"{now_information.Replace(' ', '*')}\",\"{staff_information}\",\"{row["狀態"]}\") /></a></label>";
            }
            else if (field_name == "工單狀態")
            {
                if (DataTableUtils.toString(row["狀態"]) == "ERROR")
                    value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單維護"]}\" style=\"font - weight:normal;margin-bottom:0px \"><a href=\"javascript:void(0)\" ><img src=\"../../assets/images/Light_ExStopping.PNG\"  width=\"50px\" height=\"50px\"  /></a></label>";
                else if (DataTableUtils.toString(row["狀態"]) != "ERROR" && DataTableUtils.toString(row["狀態"]) != "")
                    value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單維護"]}\" style=\"font - weight:normal;margin-bottom:0px \"><a href=\"javascript:void(0)\" ><img src=\"../../assets/images/Light_Stopping.PNG\"  width=\"50px\" height=\"50px\"  /></a></label>";
                else
                    value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單維護"]}\" style=\"font - weight:normal;margin-bottom:0px \"><a href=\"javascript:void(0)\" ><img src=\"../../assets/images/Light_Running.png\"  width=\"50px\" height=\"50px\"  /></a></label>";
            }
            else if (field_name == "開工時間")
                value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單維護"]}\" style=\"font - weight:normal;margin-bottom:0px \">{HtmlUtil.StrToDate(row[field_name].ToString()):yyyy/MM/dd HH:mm:ss}</label>";
            else if (field_name == "進度")
                value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單維護"]}\" style=\"font - weight:normal;margin-bottom:0px \">{DataTableUtils.toDouble(row[field_name]):0}%</label>";

            else
                value = $"<label id=\"{row["設備代號"]}_{field_name}_{row["工單維護"]}\" style=\"font - weight:normal;margin-bottom:0px \">{row[field_name]}</label>";
            return value == "" ? "" : $"<td align=\"center\" style=\"vertical-align:middle; color: black; \">{value}</td>";
        }

        //工單出站                                                            //200
        private bool Order_Exit(DataTable dt_main, DataTable dt_other, double Report_Qty, string now_time)
        {
            bool ok = true;
            int count = 0;
            int total = dt_main.Rows.Count;
            foreach (DataRow row in dt_main.Rows)
            {
                //目標數量  50
                double target_qty = DataTableUtils.toInt(DataTableUtils.toString(row["exp_product_count_day"]));

                //已生產數量 0
                double producted_qty = DataTableUtils.toInt(DataTableUtils.toString(row["product_count_day"]));
                //剩餘數量 回報數量+已生產數量-目標數量
                double last_qty = Report_Qty + producted_qty - target_qty;

                if (last_qty >= 0)
                    Report_Qty = last_qty;

                if (dt_other == null && count == total - 1 && Report_Qty >= 0 && last_qty >= 0)
                    target_qty = target_qty + Report_Qty;


                DataRow rows = dt_main.NewRow();
                rows["_id"] = row["_id"];

                //
                rows["product_count_day"] = last_qty >= 0 ? target_qty : producted_qty + Report_Qty;
                rows["no_product_count_day"] = last_qty >= 0 ? 0 : target_qty - (producted_qty + Report_Qty);
                //
                rows["good_qty"] = last_qty >= 0 ? target_qty - producted_qty : Report_Qty; 
                rows["last_updatetime"] = now_time;
                rows["order_status"] = "出站";
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                if (DataTableUtils.Update_DataRow("workorder_information", $"mach_name='{row["mach_name"]}'  and manu_id='{row["manu_id"]}' and type_mode='進站維護'", rows))
                {
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    string sqlcmd = $"SELECT * FROM (SELECT *, (SELECT MIN(a.now_time) FROM record_worktime a WHERE workman_status = '出站' AND a.mach_name = record_worktime.mach_name AND a.work_staff = record_worktime.work_staff AND a.now_time >= record_worktime.now_time AND a.manu_id = record_worktime.manu_id) exit_time FROM record_worktime WHERE workman_status = '入站') a WHERE a.exit_time IS NULL AND product_number = '{row["product_number"]}' AND mach_name = '{row["mach_name"]}' AND now_time <= '{now_time}' AND manu_id = '{row["manu_id"]}' and type_mode = '進站維護'";
                    DataTable dt_insert = DataTableUtils.GetDataTable(sqlcmd);
                    if (HtmlUtil.Check_DataTable(dt_insert))
                    {
                        DataTable dt_clone = dt_insert.Clone();
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                        sqlcmd = "SELECT max(_id) _id FROM record_worktime";
                        DataTable dt_max = DataTableUtils.GetDataTable(sqlcmd);
                        int max = HtmlUtil.Check_DataTable(dt_max) ? DataTableUtils.toInt(dt_max.Rows[0]["_id"].ToString()) + 1 : 1;
                        int j = 0;
                        foreach (DataRow dtrow in dt_insert.Rows)
                        {
                            rows = dt_clone.NewRow();
                            rows["_id"] = max + j;
                            rows["mach_name"] = dtrow["mach_name"];

                            rows["manu_id"] = dtrow["manu_id"];
                            rows["product_number"] = dtrow["product_number"];
                            rows["product_name"] = dtrow["product_name"];
                            rows["work_staff"] = dtrow["work_staff"];
                            rows["workman_status"] = "出站";

                            //
                            rows["report_qty"] = last_qty >= 0 ? target_qty - producted_qty : Report_Qty;
                            //

                            rows["qty_status"] = "良品";
                            rows["now_time"] = now_time;
                            rows["type_mode"] = "進站維護";
                            dt_clone.Rows.Add(rows);
                            j++;
                        }
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                        if (dt_clone.Rows.Count == DataTableUtils.Insert_TableRows("record_worktime", dt_clone))
                        {
                            ok = true;
                            count++;
                            if (dt_other != null)
                            {
                                if (last_qty >= 0)
                                    Order_Exit(dt_other, null, Report_Qty, now_time);
                                else
                                    Order_Exit(dt_other, null, 0, now_time);
                            }

                            if (dt_other == null && last_qty < 0)
                                Report_Qty = 0;
                        }
                        else
                            return false;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            return ok;
        }


        //不良填寫
        private bool BadQty_Record(DataTable dt, double Bad_Qty, string now_time, string Bad_List)
        {
            //沒有不良數量
            if (Bad_Qty == 0)
                return true;
            else
            {
                List<string> list = new List<string>(Bad_List.Split('#'));
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                string sqlcmd = "select * from bad_total";
                DataTable dt_bad = DataTableUtils.GetDataTable(sqlcmd);
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = "select max(id) id from bad_total";
                DataTable dt_max = DataTableUtils.GetDataTable(sqlcmd);
                int max = HtmlUtil.Check_DataTable(dt_max) ? DataTableUtils.toInt(DataTableUtils.toString(dt_max.Rows[0]["id"])) + 1 : 1;
                int j = 0;
                if (dt_bad != null)
                {
                    DataTable dt_clone = dt_bad.Clone();
                    for (int i = 0; i < list.Count - 1; i++)
                    {
                        DataRow row = dt_clone.NewRow();
                        row["id"] = max + j;
                        row["mach_name"] = dt.Rows[0]["mach_name"];
                        row["manu_id"] = dt.Rows[0]["manu_id"];
                        row["now_time"] = now_time;
                        row["bad_qty"] = DataTableUtils.toDouble(list[i + 1]) * DataTableUtils.toDouble(DataTableUtils.toString(dt.Rows[0]["division"])) / DataTableUtils.toDouble(DataTableUtils.toString(dt.Rows[0]["multiplication"]));
                        row["exp_product_count_day"] = dt.Rows[0]["exp_product_count_day"];
                        row["work_staff"] = dt.Rows[0]["history_workstaff"];
                        row["type_mode"] = dt.Rows[0]["type_mode"];
                        row["product_number"] = dt.Rows[0]["product_number"];
                        row["delivery"] = dt.Rows[0]["delivery"];
                        row["bad_type"] = list[i + 0];
                        row["bad_content"] = list[i + 2];
                        dt_clone.Rows.Add(row);
                        i = i + 2;
                        j++;
                    }
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    if (dt_clone.Rows.Count == DataTableUtils.Insert_TableRows("bad_total", dt_clone))
                        return true;
                    else
                        return false;
                }
                else
                    return false;
            }
        }
    }
}